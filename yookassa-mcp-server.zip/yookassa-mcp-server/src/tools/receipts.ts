import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { getClient } from '../services/client.js';
import { formatReceiptMarkdown, formatPaymentMethodMarkdown } from '../services/formatters.js';
import { FiscalReceipt, SavedPaymentMethod, YooKassaList, ResponseFormat } from '../types.js';
import { DEFAULT_LIMIT, MAX_LIMIT, RECEIPT_TYPES } from '../constants.js';

const RF = z.nativeEnum(ResponseFormat).default(ResponseFormat.MARKDOWN);

const GetReceiptSchema = z.object({
  receipt_id: z.string().min(1).describe('Receipt ID'),
  response_format: RF,
}).strict();
type GetReceiptInput = z.infer<typeof GetReceiptSchema>;

const ListReceiptsSchema = z.object({
  limit: z.number().int().min(1).max(MAX_LIMIT).default(DEFAULT_LIMIT).describe('Results per page'),
  cursor: z.string().optional().describe('Pagination cursor'),
  payment_id: z.string().optional().describe('Filter by payment ID'),
  refund_id: z.string().optional().describe('Filter by refund ID'),
  type: z.enum(RECEIPT_TYPES).optional().describe('Receipt type'),
  response_format: RF,
}).strict();
type ListReceiptsInput = z.infer<typeof ListReceiptsSchema>;

const GetPaymentMethodSchema = z.object({
  payment_method_id: z.string().min(1).describe('Saved payment method ID'),
  response_format: RF,
}).strict();
type GetPaymentMethodInput = z.infer<typeof GetPaymentMethodSchema>;

const ListPaymentMethodsSchema = z.object({
  limit: z.number().int().min(1).max(MAX_LIMIT).default(DEFAULT_LIMIT).describe('Results per page'),
  cursor: z.string().optional().describe('Pagination cursor'),
  response_format: RF,
}).strict();
type ListPaymentMethodsInput = z.infer<typeof ListPaymentMethodsSchema>;

export function registerReceiptTools(server: McpServer): void {
  server.registerTool('yookassa_get_receipt', {
    title: 'Get Receipt',
    description: `Retrieve a fiscal receipt (54-ФЗ) by ID.

Args:
  - receipt_id (string): Receipt ID
  - response_format: "markdown" | "json"

Returns: Receipt with type, status, items, fiscal registration details.`,
    inputSchema: GetReceiptSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  }, async (params: GetReceiptInput) => {
    const receipt = await getClient().get<FiscalReceipt>(`/receipts/${params.receipt_id}`);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(receipt, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatReceiptMarkdown(receipt) }] };
  });

  server.registerTool('yookassa_list_receipts', {
    title: 'List Receipts',
    description: `Get a list of fiscal receipts (54-ФЗ) with optional filters.

Args:
  - limit (number): 1–${MAX_LIMIT} (default: ${DEFAULT_LIMIT})
  - cursor (string, optional): Pagination cursor
  - payment_id (string, optional): Filter by payment ID
  - refund_id (string, optional): Filter by refund ID
  - type: "payment" | "refund"
  - response_format: "markdown" | "json"

Returns: List of fiscal receipts.`,
    inputSchema: ListReceiptsSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  }, async (params: ListReceiptsInput) => {
    const query: Record<string, unknown> = { limit: params.limit };
    if (params.cursor) query['cursor'] = params.cursor;
    if (params.payment_id) query['payment_id'] = params.payment_id;
    if (params.refund_id) query['refund_id'] = params.refund_id;
    if (params.type) query['type'] = params.type;

    const data = await getClient().get<YooKassaList<FiscalReceipt>>('/receipts', query);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(data, null, 2) }] };
    }
    if (!data.items.length) {
      return { content: [{ type: 'text' as const, text: '_No receipts found._' }] };
    }
    const lines = data.items.map(r =>
      `- \`${r.id}\` | ${r.type} | **${r.status}** | ${r.payment_id ?? r.refund_id ?? '—'} | ${r.registered_at?.slice(0, 10) ?? 'pending'}`
    );
    const pagination = data.next_cursor ? `\n\n_Next cursor: \`${data.next_cursor}\`_` : '';
    return { content: [{ type: 'text' as const, text: `### Receipts (${data.items.length})\n${lines.join('\n')}${pagination}` }] };
  });
}

export function registerPaymentMethodTools(server: McpServer): void {
  server.registerTool('yookassa_get_payment_method', {
    title: 'Get Saved Payment Method',
    description: `Retrieve a saved payment method (e.g. saved card for recurring) by ID.

Args:
  - payment_method_id (string): Saved payment method ID
  - response_format: "markdown" | "json"

Returns: Payment method with type, card details, save status.`,
    inputSchema: GetPaymentMethodSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  }, async (params: GetPaymentMethodInput) => {
    const method = await getClient().get<SavedPaymentMethod>(`/payment_methods/${params.payment_method_id}`);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(method, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatPaymentMethodMarkdown(method) }] };
  });

  server.registerTool('yookassa_list_payment_methods', {
    title: 'List Saved Payment Methods',
    description: `Get saved payment methods for recurring/autopayments.

Args:
  - limit (number): 1–${MAX_LIMIT} (default: ${DEFAULT_LIMIT})
  - cursor (string, optional): Pagination cursor
  - response_format: "markdown" | "json"

Returns: List of saved payment methods with types and card details.`,
    inputSchema: ListPaymentMethodsSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  }, async (params: ListPaymentMethodsInput) => {
    const query: Record<string, unknown> = { limit: params.limit };
    if (params.cursor) query['cursor'] = params.cursor;

    const data = await getClient().get<YooKassaList<SavedPaymentMethod>>('/payment_methods', query);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(data, null, 2) }] };
    }
    if (!data.items.length) {
      return { content: [{ type: 'text' as const, text: '_No saved payment methods found._' }] };
    }
    const lines = data.items.map(m =>
      `- \`${m.id}\` | ${m.type}${m.title ? ` | ${m.title}` : ''}${m.card ? ` | *${m.card.last4}` : ''}`
    );
    const pagination = data.next_cursor ? `\n\n_Next cursor: \`${data.next_cursor}\`_` : '';
    return { content: [{ type: 'text' as const, text: `### Saved Payment Methods (${data.items.length})\n${lines.join('\n')}${pagination}` }] };
  });
}
