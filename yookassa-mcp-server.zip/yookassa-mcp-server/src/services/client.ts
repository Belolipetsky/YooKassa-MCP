import axios, { AxiosInstance, AxiosError } from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { YOOKASSA_API_URL } from '../constants.js';

export class YooKassaClient {
  private client: AxiosInstance;

  constructor(shopId: string, secretKey: string) {
    this.client = axios.create({
      baseURL: YOOKASSA_API_URL,
      auth: {
        username: shopId,
        password: secretKey,
      },
      headers: {
        'Content-Type': 'application/json',
      },
      timeout: 30_000,
    });
  }

  async get<T>(path: string, params?: Record<string, unknown>): Promise<T> {
    try {
      const response = await this.client.get<T>(path, { params });
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  async post<T>(path: string, data?: unknown, idempotenceKey?: string): Promise<T> {
    try {
      const response = await this.client.post<T>(path, data, {
        headers: {
          'Idempotence-Key': idempotenceKey ?? uuidv4(),
        },
      });
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  async delete<T>(path: string): Promise<T> {
    try {
      const response = await this.client.delete<T>(path);
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  private handleError(error: unknown): Error {
    if (axios.isAxiosError(error)) {
      const axiosError = error as AxiosError<{
        type?: string;
        id?: string;
        code?: string;
        description?: string;
        parameter?: string;
      }>;

      const status = axiosError.response?.status;
      const data = axiosError.response?.data;

      if (status === 401) {
        return new Error(
          'Authentication failed. Check YOOKASSA_SHOP_ID and YOOKASSA_SECRET_KEY environment variables.'
        );
      }
      if (status === 403) {
        return new Error(`Access forbidden: ${data?.description ?? 'insufficient permissions'}`);
      }
      if (status === 404) {
        return new Error(`Resource not found: ${data?.description ?? 'check the ID'}`);
      }
      if (status === 422) {
        return new Error(
          `Validation error on parameter '${data?.parameter ?? 'unknown'}': ${data?.description ?? 'invalid value'}`
        );
      }
      if (status === 429) {
        return new Error('Rate limit exceeded. Reduce request frequency and retry.');
      }

      const message = data?.description ?? axiosError.message ?? 'Unknown API error';
      const code = data?.code ? ` [${data.code}]` : '';
      return new Error(`YooKassa API error${code}: ${message}`);
    }

    if (error instanceof Error) return error;
    return new Error(String(error));
  }
}

let _client: YooKassaClient | null = null;

export function getClient(): YooKassaClient {
  if (_client) return _client;

  const shopId = process.env['YOOKASSA_SHOP_ID'];
  const secretKey = process.env['YOOKASSA_SECRET_KEY'];

  if (!shopId || !secretKey) {
    throw new Error(
      'Missing credentials. Set YOOKASSA_SHOP_ID and YOOKASSA_SECRET_KEY environment variables.'
    );
  }

  _client = new YooKassaClient(shopId, secretKey);
  return _client;
}
