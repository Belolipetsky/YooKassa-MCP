import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { getClient } from '../services/client.js';
import { formatPaymentMarkdown, formatPaymentListMarkdown } from '../services/formatters.js';
import { Payment, YooKassaList, ResponseFormat } from '../types.js';
import { DEFAULT_LIMIT, MAX_LIMIT, PAYMENT_STATUSES, CURRENCIES, PAYMENT_METHODS } from '../constants.js';

const RF = z.nativeEnum(ResponseFormat).default(ResponseFormat.MARKDOWN);

const CreatePaymentSchema = z.object({
  amount: z.string().regex(/^\d+(\.\d{1,2})?$/).describe('Amount e.g. "100.00"'),
  currency: z.enum(CURRENCIES).default('RUB').describe('Currency'),
  description: z.string().max(128).optional().describe('Order description'),
  return_url: z.string().url().optional().describe('Redirect URL after confirmation'),
  capture: z.boolean().default(true).describe('Auto-capture (true) or hold (false)'),
  payment_method_type: z.enum(PAYMENT_METHODS).optional().describe('Payment method type'),
  metadata: z.record(z.string()).optional().describe('Custom key-value metadata'),
  save_payment_method: z.boolean().optional().describe('Save for recurring payments'),
  idempotence_key: z.string().optional().describe('Idempotency key'),
  response_format: RF,
}).strict();
type CreatePaymentInput = z.infer<typeof CreatePaymentSchema>;

const GetPaymentSchema = z.object({
  payment_id: z.string().min(1).describe('Payment ID'),
  response_format: RF,
}).strict();
type GetPaymentInput = z.infer<typeof GetPaymentSchema>;

const ListPaymentsSchema = z.object({
  limit: z.number().int().min(1).max(MAX_LIMIT).default(DEFAULT_LIMIT).describe('Results per page'),
  cursor: z.string().optional().describe('Pagination cursor'),
  status: z.enum(PAYMENT_STATUSES).optional().describe('Filter by status'),
  payment_method: z.enum(PAYMENT_METHODS).optional().describe('Filter by payment method'),
  created_at_gte: z.string().optional().describe('Created at or after (ISO 8601)'),
  created_at_lte: z.string().optional().describe('Created before or at (ISO 8601)'),
  captured_at_gte: z.string().optional().describe('Captured at or after (ISO 8601)'),
  captured_at_lte: z.string().optional().describe('Captured before or at (ISO 8601)'),
  response_format: RF,
}).strict();
type ListPaymentsInput = z.infer<typeof ListPaymentsSchema>;

const CapturePaymentSchema = z.object({
  payment_id: z.string().min(1).describe('Payment ID to capture'),
  amount: z.string().regex(/^\d+(\.\d{1,2})?$/).optional().describe('Partial capture amount'),
  currency: z.enum(CURRENCIES).default('RUB').describe('Currency'),
  response_format: RF,
}).strict();
type CapturePaymentInput = z.infer<typeof CapturePaymentSchema>;

const CancelPaymentSchema = z.object({
  payment_id: z.string().min(1).describe('Payment ID to cancel'),
  response_format: RF,
}).strict();
type CancelPaymentInput = z.infer<typeof CancelPaymentSchema>;

export function registerPaymentTools(server: McpServer): void {
  server.registerTool('yookassa_create_payment', {
    title: 'Create Payment',
    description: `Create a YooKassa payment and get a confirmation URL for the user.

Args:
  - amount (string): Amount e.g. "100.00"
  - currency: "RUB" | "USD" | "EUR" (default: "RUB")
  - description (string, optional): Order description (max 128 chars)
  - return_url (string, optional): Redirect URL after confirmation
  - capture (boolean): Auto-capture (default: true) or hold
  - payment_method_type (string, optional): bank_card | sbp | yoo_money | etc.
  - metadata (object, optional): Custom key-value data
  - save_payment_method (boolean, optional): Save for recurring
  - idempotence_key (string, optional): Deduplication key
  - response_format: "markdown" | "json" (default: markdown)

Returns: Payment object with id, status, confirmation_url, amount.`,
    inputSchema: CreatePaymentSchema,
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
  }, async (params: CreatePaymentInput) => {
    const client = getClient();
    const body: Record<string, unknown> = {
      amount: { value: params.amount, currency: params.currency },
      capture: params.capture,
      confirmation: { type: 'redirect', return_url: params.return_url ?? 'https://yookassa.ru/' },
    };
    if (params.description) body['description'] = params.description;
    if (params.metadata) body['metadata'] = params.metadata;
    if (params.save_payment_method) body['save_payment_method'] = params.save_payment_method;
    if (params.payment_method_type) body['payment_method_data'] = { type: params.payment_method_type };

    const payment = await client.post<Payment>('/payments', body, params.idempotence_key);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(payment, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatPaymentMarkdown(payment) }] };
  });

  server.registerTool('yookassa_get_payment', {
    title: 'Get Payment',
    description: `Retrieve a single payment by ID.

Args:
  - payment_id (string): Payment ID
  - response_format: "markdown" | "json"

Returns: Full payment object with status, amount, method, timestamps.`,
    inputSchema: GetPaymentSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  }, async (params: GetPaymentInput) => {
    const payment = await getClient().get<Payment>(`/payments/${params.payment_id}`);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(payment, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatPaymentMarkdown(payment) }] };
  });

  server.registerTool('yookassa_list_payments', {
    title: 'List Payments',
    description: `Get a paginated list of payments with filters.

Args:
  - limit (number): 1–${MAX_LIMIT} (default: ${DEFAULT_LIMIT})
  - cursor (string, optional): Pagination cursor from previous response
  - status: pending | waiting_for_capture | succeeded | canceled
  - payment_method: bank_card | sbp | yoo_money | etc.
  - created_at_gte / created_at_lte (ISO 8601 date range)
  - captured_at_gte / captured_at_lte (ISO 8601 date range)
  - response_format: "markdown" | "json"

Returns: List of payments + next_cursor if more pages exist.`,
    inputSchema: ListPaymentsSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  }, async (params: ListPaymentsInput) => {
    const query: Record<string, unknown> = { limit: params.limit };
    if (params.cursor) query['cursor'] = params.cursor;
    if (params.status) query['status'] = params.status;
    if (params.payment_method) query['payment_method'] = params.payment_method;
    if (params.created_at_gte) query['created_at.gte'] = params.created_at_gte;
    if (params.created_at_lte) query['created_at.lte'] = params.created_at_lte;
    if (params.captured_at_gte) query['captured_at.gte'] = params.captured_at_gte;
    if (params.captured_at_lte) query['captured_at.lte'] = params.captured_at_lte;

    const data = await getClient().get<YooKassaList<Payment>>('/payments', query);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(data, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatPaymentListMarkdown(data.items, undefined, data.next_cursor) }] };
  });

  server.registerTool('yookassa_capture_payment', {
    title: 'Capture Payment',
    description: `Capture a payment in "waiting_for_capture" status (two-stage payment).

Args:
  - payment_id (string): Payment ID to capture
  - amount (string, optional): Partial capture amount. Omit for full capture.
  - currency: "RUB" | "USD" | "EUR" (default: "RUB")
  - response_format: "markdown" | "json"

Returns: Payment with status "succeeded".`,
    inputSchema: CapturePaymentSchema,
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
  }, async (params: CapturePaymentInput) => {
    const body: Record<string, unknown> = {};
    if (params.amount) body['amount'] = { value: params.amount, currency: params.currency };
    const payment = await getClient().post<Payment>(`/payments/${params.payment_id}/capture`, body);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(payment, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatPaymentMarkdown(payment) }] };
  });

  server.registerTool('yookassa_cancel_payment', {
    title: 'Cancel Payment',
    description: `Cancel a payment in "waiting_for_capture" status. Releases held funds.

Args:
  - payment_id (string): Payment ID to cancel
  - response_format: "markdown" | "json"

Returns: Payment with status "canceled".`,
    inputSchema: CancelPaymentSchema,
    annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: true, openWorldHint: true },
  }, async (params: CancelPaymentInput) => {
    const payment = await getClient().post<Payment>(`/payments/${params.payment_id}/cancel`, {});
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(payment, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatPaymentMarkdown(payment) }] };
  });
}
