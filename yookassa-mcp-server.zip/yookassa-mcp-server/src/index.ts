#!/usr/bin/env node
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import express, { Request, Response } from 'express';

import { registerPaymentTools } from './tools/payments.js';
import { registerRefundTools } from './tools/refunds.js';
import { registerWebhookTools } from './tools/webhooks.js';
import { registerReceiptTools, registerPaymentMethodTools } from './tools/receipts.js';

const server = new McpServer({
  name: 'yookassa-mcp-server',
  version: '1.0.0',
});

// Register all tool groups
registerPaymentTools(server);
registerRefundTools(server);
registerWebhookTools(server);
registerReceiptTools(server);
registerPaymentMethodTools(server);

// ── HTTP transport ─────────────────────────────────────────────────────────
async function runHTTP(): Promise<void> {
  const app = express();
  app.use(express.json());

  app.get('/health', (_req: Request, res: Response) => {
    res.json({ status: 'ok', server: 'yookassa-mcp-server', version: '1.0.0' });
  });

  app.post('/mcp', async (req: Request, res: Response) => {
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
      enableJsonResponse: true,
    });
    res.on('close', () => transport.close());
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  });

  const port = parseInt(process.env['PORT'] ?? '3000', 10);
  app.listen(port, () => {
    console.error(`YooKassa MCP server running on http://localhost:${port}/mcp`);
  });
}

// ── stdio transport ────────────────────────────────────────────────────────
async function runStdio(): Promise<void> {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('YooKassa MCP server running on stdio');
}

// ── Entry point ────────────────────────────────────────────────────────────
const transport = process.env['TRANSPORT'] ?? 'stdio';

if (transport === 'http') {
  runHTTP().catch((error: unknown) => {
    console.error('Server error:', error);
    process.exit(1);
  });
} else {
  runStdio().catch((error: unknown) => {
    console.error('Server error:', error);
    process.exit(1);
  });
}
