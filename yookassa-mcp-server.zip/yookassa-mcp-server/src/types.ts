// YooKassa API types

export interface Amount {
  value: string;
  currency: string;
}

export interface Recipient {
  account_id: string;
  gateway_id: string;
}

export interface Confirmation {
  type: string;
  confirmation_url?: string;
  return_url?: string;
  enforce?: boolean;
}

export interface PaymentMethod {
  type: string;
  id?: string;
  saved?: boolean;
  title?: string;
  card?: {
    first6?: string;
    last4?: string;
    expiry_month?: string;
    expiry_year?: string;
    card_type?: string;
    issuer_country?: string;
    issuer_name?: string;
  };
}

export interface AuthorizationDetails {
  rrn?: string;
  auth_code?: string;
  three_d_secure?: { applied: boolean };
}

export interface CancellationDetails {
  party: string;
  reason: string;
}

export interface Transfer {
  account_id: string;
  amount: Amount;
  platform_fee_amount?: Amount;
  description?: string;
  metadata?: Record<string, unknown>;
}

export interface ReceiptCustomer {
  full_name?: string;
  inn?: string;
  email?: string;
  phone?: string;
}

export interface ReceiptItem {
  description: string;
  quantity: number;
  amount: Amount;
  vat_code: number;
  payment_subject?: string;
  payment_mode?: string;
}

export interface Receipt {
  customer?: ReceiptCustomer;
  items?: ReceiptItem[];
  phone?: string;
  email?: string;
  tax_system_code?: number;
}

// Payment object
export interface Payment {
  id: string;
  status: 'pending' | 'waiting_for_capture' | 'succeeded' | 'canceled';
  amount: Amount;
  income_amount?: Amount;
  description?: string;
  recipient: Recipient;
  payment_method?: PaymentMethod;
  captured_at?: string;
  created_at: string;
  expires_at?: string;
  confirmation?: Confirmation;
  test: boolean;
  refunded_amount?: Amount;
  paid: boolean;
  refundable: boolean;
  receipt_registration?: string;
  metadata?: Record<string, unknown>;
  cancellation_details?: CancellationDetails;
  authorization_details?: AuthorizationDetails;
  transfers?: Transfer[];
}

// Refund object
export interface Refund {
  id: string;
  payment_id: string;
  status: 'pending' | 'succeeded' | 'canceled';
  cancellation_details?: CancellationDetails;
  amount: Amount;
  description?: string;
  sources?: Transfer[];
  created_at: string;
  receipt_registration?: string;
  metadata?: Record<string, unknown>;
}

// Receipt object
export interface FiscalReceipt {
  id: string;
  type: 'payment' | 'refund';
  payment_id?: string;
  refund_id?: string;
  status: 'pending' | 'succeeded' | 'canceled';
  fiscal_document_number?: string;
  fiscal_storage_number?: string;
  fiscal_attribute?: string;
  registered_at?: string;
  fiscal_provider_id?: string;
  items: ReceiptItem[];
  tax_system_code?: number;
  receipt_registration?: string;
}

// Webhook object
export interface Webhook {
  id: string;
  event: string;
  url: string;
}

// Payment method saved
export interface SavedPaymentMethod {
  type: string;
  id: string;
  saved: boolean;
  title?: string;
  created_at?: string;
  card?: PaymentMethod['card'];
}

// List response
export interface YooKassaList<T> {
  type: 'list';
  items: T[];
  next_cursor?: string;
}

// MCP tool response format
export enum ResponseFormat {
  MARKDOWN = 'markdown',
  JSON = 'json',
}
