import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { getClient } from '../services/client.js';
import { formatWebhookMarkdown, formatWebhookListMarkdown } from '../services/formatters.js';
import { Webhook, YooKassaList, ResponseFormat } from '../types.js';
import { WEBHOOK_EVENTS } from '../constants.js';

const RF = z.nativeEnum(ResponseFormat).default(ResponseFormat.MARKDOWN);

const CreateWebhookSchema = z.object({
  event: z.enum(WEBHOOK_EVENTS).describe('Event to subscribe to'),
  url: z.string().url().startsWith('https://', 'Webhook URL must use HTTPS').describe('Notification URL (must be HTTPS)'),
  response_format: RF,
}).strict();
type CreateWebhookInput = z.infer<typeof CreateWebhookSchema>;

const ListWebhooksSchema = z.object({ response_format: RF }).strict();
type ListWebhooksInput = z.infer<typeof ListWebhooksSchema>;

const DeleteWebhookSchema = z.object({
  webhook_id: z.string().min(1).describe('Webhook ID to delete'),
  response_format: RF,
}).strict();
type DeleteWebhookInput = z.infer<typeof DeleteWebhookSchema>;

export function registerWebhookTools(server: McpServer): void {
  server.registerTool('yookassa_create_webhook', {
    title: 'Create Webhook',
    description: `Subscribe to a YooKassa event with a webhook.

Available events:
  payment.canceled | payment.succeeded | payment.waiting_for_capture
  refund.succeeded | payout.canceled | payout.succeeded
  deal.closed | payment.refund_reversed

Args:
  - event (string): Event name to subscribe to
  - url (string): HTTPS URL to receive POST notifications
  - response_format: "markdown" | "json"

Returns: Webhook object with id, event, url.

Note: Only one webhook per event per token. URL must be HTTPS.`,
    inputSchema: CreateWebhookSchema,
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true },
  }, async (params: CreateWebhookInput) => {
    const webhook = await getClient().post<Webhook>('/webhooks', { event: params.event, url: params.url });
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(webhook, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatWebhookMarkdown(webhook) }] };
  });

  server.registerTool('yookassa_list_webhooks', {
    title: 'List Webhooks',
    description: `Get all configured webhooks for your YooKassa account.

Args:
  - response_format: "markdown" | "json"

Returns: List of webhooks with ids, events, and URLs.`,
    inputSchema: ListWebhooksSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  }, async (params: ListWebhooksInput) => {
    const data = await getClient().get<YooKassaList<Webhook>>('/webhooks');
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(data, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatWebhookListMarkdown(data.items) }] };
  });

  server.registerTool('yookassa_delete_webhook', {
    title: 'Delete Webhook',
    description: `Unsubscribe from an event by deleting a webhook.

Args:
  - webhook_id (string): Webhook ID (from yookassa_list_webhooks)
  - response_format: "markdown" | "json"

Returns: Deletion confirmation.`,
    inputSchema: DeleteWebhookSchema,
    annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: true, openWorldHint: true },
  }, async (params: DeleteWebhookInput) => {
    await getClient().delete(`/webhooks/${params.webhook_id}`);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify({ deleted: true, id: params.webhook_id }) }] };
    }
    return { content: [{ type: 'text' as const, text: `Webhook \`${params.webhook_id}\` deleted successfully.` }] };
  });
}
