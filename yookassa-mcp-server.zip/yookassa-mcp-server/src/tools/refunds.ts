import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { getClient } from '../services/client.js';
import { formatRefundMarkdown, formatRefundListMarkdown } from '../services/formatters.js';
import { Refund, YooKassaList, ResponseFormat } from '../types.js';
import { DEFAULT_LIMIT, MAX_LIMIT, REFUND_STATUSES, CURRENCIES } from '../constants.js';

const RF = z.nativeEnum(ResponseFormat).default(ResponseFormat.MARKDOWN);

const CreateRefundSchema = z.object({
  payment_id: z.string().min(1).describe('Payment ID to refund'),
  amount: z.string().regex(/^\d+(\.\d{1,2})?$/).optional().describe('Refund amount (omit for full refund)'),
  currency: z.enum(CURRENCIES).default('RUB').describe('Currency'),
  description: z.string().max(250).optional().describe('Refund reason'),
  idempotence_key: z.string().optional().describe('Idempotency key'),
  response_format: RF,
}).strict();
type CreateRefundInput = z.infer<typeof CreateRefundSchema>;

const GetRefundSchema = z.object({
  refund_id: z.string().min(1).describe('Refund ID'),
  response_format: RF,
}).strict();
type GetRefundInput = z.infer<typeof GetRefundSchema>;

const ListRefundsSchema = z.object({
  limit: z.number().int().min(1).max(MAX_LIMIT).default(DEFAULT_LIMIT).describe('Results per page'),
  cursor: z.string().optional().describe('Pagination cursor'),
  payment_id: z.string().optional().describe('Filter by payment ID'),
  status: z.enum(REFUND_STATUSES).optional().describe('Filter by status'),
  created_at_gte: z.string().optional().describe('Created at or after (ISO 8601)'),
  created_at_lte: z.string().optional().describe('Created before or at (ISO 8601)'),
  response_format: RF,
}).strict();
type ListRefundsInput = z.infer<typeof ListRefundsSchema>;

export function registerRefundTools(server: McpServer): void {
  server.registerTool('yookassa_create_refund', {
    title: 'Create Refund',
    description: `Create a full or partial refund for a succeeded payment.

Args:
  - payment_id (string): Payment ID to refund
  - amount (string, optional): Refund amount e.g. "250.00". Omit for full refund.
  - currency: "RUB" | "USD" | "EUR" (default: "RUB")
  - description (string, optional): Refund reason (max 250 chars)
  - idempotence_key (string, optional): Deduplication key
  - response_format: "markdown" | "json"

Returns: Refund object with id, status, amount, payment_id.

Error: Fails if payment is not refundable or amount exceeds refundable amount.`,
    inputSchema: CreateRefundSchema,
    annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: false, openWorldHint: true },
  }, async (params: CreateRefundInput) => {
    const body: Record<string, unknown> = { payment_id: params.payment_id };
    if (params.amount) body['amount'] = { value: params.amount, currency: params.currency };
    if (params.description) body['description'] = params.description;

    const refund = await getClient().post<Refund>('/refunds', body, params.idempotence_key);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(refund, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatRefundMarkdown(refund) }] };
  });

  server.registerTool('yookassa_get_refund', {
    title: 'Get Refund',
    description: `Retrieve a single refund by ID.

Args:
  - refund_id (string): Refund ID
  - response_format: "markdown" | "json"

Returns: Refund object with status, amount, payment_id, timestamps.`,
    inputSchema: GetRefundSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  }, async (params: GetRefundInput) => {
    const refund = await getClient().get<Refund>(`/refunds/${params.refund_id}`);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(refund, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatRefundMarkdown(refund) }] };
  });

  server.registerTool('yookassa_list_refunds', {
    title: 'List Refunds',
    description: `Get a paginated list of refunds with optional filters.

Args:
  - limit (number): 1–${MAX_LIMIT} (default: ${DEFAULT_LIMIT})
  - cursor (string, optional): Pagination cursor
  - payment_id (string, optional): Filter by payment ID
  - status: pending | succeeded | canceled
  - created_at_gte / created_at_lte (ISO 8601 date range)
  - response_format: "markdown" | "json"

Returns: List of refunds + next_cursor if more pages exist.`,
    inputSchema: ListRefundsSchema,
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  }, async (params: ListRefundsInput) => {
    const query: Record<string, unknown> = { limit: params.limit };
    if (params.cursor) query['cursor'] = params.cursor;
    if (params.payment_id) query['payment_id'] = params.payment_id;
    if (params.status) query['status'] = params.status;
    if (params.created_at_gte) query['created_at.gte'] = params.created_at_gte;
    if (params.created_at_lte) query['created_at.lte'] = params.created_at_lte;

    const data = await getClient().get<YooKassaList<Refund>>('/refunds', query);
    if (params.response_format === ResponseFormat.JSON) {
      return { content: [{ type: 'text' as const, text: JSON.stringify(data, null, 2) }] };
    }
    return { content: [{ type: 'text' as const, text: formatRefundListMarkdown(data.items, data.next_cursor) }] };
  });
}
