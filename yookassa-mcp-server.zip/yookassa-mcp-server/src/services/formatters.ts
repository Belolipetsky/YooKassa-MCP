import { Payment, Refund, FiscalReceipt, Webhook, SavedPaymentMethod, Amount } from '../types.js';
import { CHARACTER_LIMIT } from '../constants.js';

export function formatAmount(amount: Amount): string {
  return `${amount.value} ${amount.currency}`;
}

export function truncate(text: string): string {
  if (text.length <= CHARACTER_LIMIT) return text;
  return text.slice(0, CHARACTER_LIMIT) + `\n\n... [truncated, ${text.length - CHARACTER_LIMIT} chars omitted]`;
}

// ── Payments ────────────────────────────────────────────────────────────────

export function formatPaymentMarkdown(p: Payment): string {
  const lines: string[] = [
    `## Payment ${p.id}`,
    `- **Status**: ${p.status}`,
    `- **Amount**: ${formatAmount(p.amount)}`,
    `- **Paid**: ${p.paid}`,
    `- **Test**: ${p.test}`,
    `- **Created**: ${p.created_at}`,
  ];
  if (p.description) lines.push(`- **Description**: ${p.description}`);
  if (p.payment_method) lines.push(`- **Payment method**: ${p.payment_method.type}${p.payment_method.title ? ` (${p.payment_method.title})` : ''}`);
  if (p.captured_at) lines.push(`- **Captured at**: ${p.captured_at}`);
  if (p.expires_at) lines.push(`- **Expires at**: ${p.expires_at}`);
  if (p.refunded_amount) lines.push(`- **Refunded**: ${formatAmount(p.refunded_amount)}`);
  if (p.cancellation_details) lines.push(`- **Cancelled by**: ${p.cancellation_details.party} — ${p.cancellation_details.reason}`);
  if (p.confirmation?.confirmation_url) lines.push(`- **Confirmation URL**: ${p.confirmation.confirmation_url}`);
  if (p.metadata && Object.keys(p.metadata).length) lines.push(`- **Metadata**: \`${JSON.stringify(p.metadata)}\``);
  return lines.join('\n');
}

export function formatPaymentListMarkdown(payments: Payment[], total?: number, nextCursor?: string): string {
  const header = total !== undefined ? `### Payments (${payments.length} of ${total})\n` : `### Payments (${payments.length})\n`;
  const body = payments.map(p =>
    `- \`${p.id}\` | **${p.status}** | ${formatAmount(p.amount)} | ${p.created_at.slice(0, 10)}${p.description ? ` | ${p.description}` : ''}`
  ).join('\n');
  const pagination = nextCursor ? `\n\n_Next cursor: \`${nextCursor}\`_` : '';
  return truncate(header + body + pagination);
}

// ── Refunds ─────────────────────────────────────────────────────────────────

export function formatRefundMarkdown(r: Refund): string {
  const lines: string[] = [
    `## Refund ${r.id}`,
    `- **Status**: ${r.status}`,
    `- **Amount**: ${formatAmount(r.amount)}`,
    `- **Payment ID**: ${r.payment_id}`,
    `- **Created**: ${r.created_at}`,
  ];
  if (r.description) lines.push(`- **Description**: ${r.description}`);
  if (r.receipt_registration) lines.push(`- **Receipt**: ${r.receipt_registration}`);
  if (r.cancellation_details) lines.push(`- **Cancelled by**: ${r.cancellation_details.party} — ${r.cancellation_details.reason}`);
  if (r.metadata && Object.keys(r.metadata).length) lines.push(`- **Metadata**: \`${JSON.stringify(r.metadata)}\``);
  return lines.join('\n');
}

export function formatRefundListMarkdown(refunds: Refund[], nextCursor?: string): string {
  const header = `### Refunds (${refunds.length})\n`;
  const body = refunds.map(r =>
    `- \`${r.id}\` | **${r.status}** | ${formatAmount(r.amount)} | payment: ${r.payment_id} | ${r.created_at.slice(0, 10)}`
  ).join('\n');
  const pagination = nextCursor ? `\n\n_Next cursor: \`${nextCursor}\`_` : '';
  return truncate(header + body + pagination);
}

// ── Receipts ─────────────────────────────────────────────────────────────────

export function formatReceiptMarkdown(r: FiscalReceipt): string {
  const lines: string[] = [
    `## Receipt ${r.id}`,
    `- **Type**: ${r.type}`,
    `- **Status**: ${r.status}`,
  ];
  if (r.payment_id) lines.push(`- **Payment ID**: ${r.payment_id}`);
  if (r.refund_id) lines.push(`- **Refund ID**: ${r.refund_id}`);
  if (r.registered_at) lines.push(`- **Registered at**: ${r.registered_at}`);
  if (r.fiscal_document_number) lines.push(`- **Fiscal document #**: ${r.fiscal_document_number}`);
  if (r.fiscal_storage_number) lines.push(`- **Fiscal storage #**: ${r.fiscal_storage_number}`);
  if (r.items?.length) {
    lines.push('\n**Items:**');
    r.items.forEach(item => lines.push(`  - ${item.description} × ${item.quantity} = ${formatAmount(item.amount)}`));
  }
  return lines.join('\n');
}

// ── Webhooks ─────────────────────────────────────────────────────────────────

export function formatWebhookMarkdown(w: Webhook): string {
  return [
    `## Webhook ${w.id}`,
    `- **Event**: ${w.event}`,
    `- **URL**: ${w.url}`,
  ].join('\n');
}

export function formatWebhookListMarkdown(webhooks: Webhook[]): string {
  if (!webhooks.length) return '_No webhooks configured._';
  const header = `### Webhooks (${webhooks.length})\n`;
  const body = webhooks.map(w => `- \`${w.id}\` | ${w.event} → ${w.url}`).join('\n');
  return header + body;
}

// ── Payment Methods ───────────────────────────────────────────────────────────

export function formatPaymentMethodMarkdown(m: SavedPaymentMethod): string {
  const lines: string[] = [
    `## Saved Payment Method ${m.id}`,
    `- **Type**: ${m.type}`,
    `- **Saved**: ${m.saved}`,
  ];
  if (m.title) lines.push(`- **Title**: ${m.title}`);
  if (m.created_at) lines.push(`- **Created**: ${m.created_at}`);
  if (m.card) {
    lines.push(`- **Card**: ${m.card.card_type ?? ''} *${m.card.last4} (${m.card.expiry_month}/${m.card.expiry_year})`);
    if (m.card.issuer_name) lines.push(`- **Bank**: ${m.card.issuer_name}`);
  }
  return lines.join('\n');
}
