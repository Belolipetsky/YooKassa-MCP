export const YOOKASSA_API_URL = 'https://api.yookassa.ru/v3';
export const DEFAULT_LIMIT = 20;
export const MAX_LIMIT = 100;
export const CHARACTER_LIMIT = 50_000;

export const PAYMENT_STATUSES = ['pending', 'waiting_for_capture', 'succeeded', 'canceled'] as const;
export const REFUND_STATUSES = ['pending', 'succeeded', 'canceled'] as const;
export const RECEIPT_TYPES = ['payment', 'refund'] as const;
export const CURRENCIES = ['RUB', 'USD', 'EUR'] as const;

export const WEBHOOK_EVENTS = [
  'payment.canceled',
  'payment.succeeded',
  'payment.waiting_for_capture',
  'refund.succeeded',
  'payout.canceled',
  'payout.succeeded',
  'deal.closed',
  'payment.refund_reversed',
] as const;

export const PAYMENT_METHODS = [
  'bank_card',
  'yoo_money',
  'sberbank',
  'alfabank',
  'tinkoff_bank',
  'b2b_sberbank',
  'sbp',
  'mobile_balance',
  'cash',
  'installments',
  'qiwi',
  'wechat',
  'webmoney',
] as const;
